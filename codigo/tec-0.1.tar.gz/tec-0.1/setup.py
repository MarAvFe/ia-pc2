from setuptools import setup

setup(name='tec',
      version='0.1',
      description='Proyecto Corto 2 - IA',
      url='https://github.com/MarAvFe/ia-pc2/',
      author='Grupo 04 IA',
      packages=['tec/ic/ia/pc2'],
      package_dir={'pc2': './tec/ic/ia/pc2'},
      package_data={'tec/ic/ia/pc2': ['*.txt']}
      )
